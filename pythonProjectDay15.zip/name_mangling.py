###name mangling - special functionality in python
### for class varibles (attributes) and methods (behaviour), there should be a access specifier
### public, private and protected

#basically, an access modifier is used to define - whether the given to class members should be accessible
## outside the class or not

##bank application
## class account
###     protected balance

### class RDAccount(account):
        ## if the balance is private, it cannot be accessed
        ## if the balance is protected, it can be used by its child class
        ## if the balance is public, it has no restriction to use

## as python doesn't have an access modifier, you can not restrict the class members from
## getting access outside the class

## to overcome this, python has a concept of name mangling

# class myClass:
#     def __init__(self):
#         self.x = 10
#         self.__y = 20
#
# obj = myClass()
# print(obj._myClass__y)
# print(obj.x)
#
# ## even though we have initialized __y variable inside the class __init__().
# ## you can not access it outside the class using the object.
#
# ## adding __ as a prefix make members private
# from pprint import pprint
# pprint(dir(obj))
#
# class myClass:
#     def myFunc(self):
#         print("Hello, World")
#
# obj = myClass()
# obj.myFunc()
#
# class Test:
#     def __myFunc(self):
#         print("Hello, World")
#
# obj = Test()
# obj._Test__myFunc()  ##_<classname>__<attrname>
#
# class baseClass():
#     def __myFunc(self):
#         print("I'm a Parent")
#
# class derivedClass(baseClass):
#     def __myFunc(self):
#         print("I'm a child")
#
#
# obj  = derivedClass()
# #how to access baseclass myFunc
# obj._baseClass__myFunc()
# #how to access derivedclass myFunc
# obj.__myFunc__()

#summary:
### the name mangling concept applies when the attribute or Func is prefixed with __

### if the attribute is prefixed with _, it will work as normal attribute

### as part of name mangling, attribute name will be changed to _<class_name><attribute>

### Using name mangling, we can access the members outside the class. This means name mangling
### is closest to making members private, but it is not the exact way of making member private

class Test:
    def __init__(self):
        self.x = 10
        self._y = 100
        self.__z = 1000

o = Test()
o.x
o._y
