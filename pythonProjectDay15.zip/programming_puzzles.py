##python program to interchange the first and last elements in a list
"""
input : [12,2,92,44]

output: [44,2,92,12]

"""

##python program to print max number from the list of integers
"""
input = [20,10,20,4,100]
output = 100

limitation: don't use inbuilt max keyword
"""

### python program to give the count of pairs whose sum is equal to k
### arr, k
"""
input: arr = [1,2,8,4,9,12,3] k=12

output: count = 2 

[1,2,8,4,9,12,3]
-> outer for loop (0, 7) 0 [1]
->     (0,1) 2

-> 1
-> (0,2)

-> 2
-> (0,3)

"""

#python program to reverse a sentence

"""
input = "This is the python bootcamp"
output = "bootcamp python the is This"
"""