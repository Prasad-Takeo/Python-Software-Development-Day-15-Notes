## write a recursive factorial program
## factorial(5) = 5 * 4 * 3 *2 *1
## factorial module

## a module is a self-contained python file that contains
## python statements and definitions like a factorial.py, which can be
## considered as a module name factorial which can be imported with the help of import statement
def recur_factorial(n):
   if n == 1:
       return n
   else:
       return n*recur_factorial(n-1)