from test.factorial import  recur_factorial
print(recur_factorial(10))

