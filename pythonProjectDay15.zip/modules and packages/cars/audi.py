class Audi:
    def __init__(self):
        self.models = ["q7", "a6", "a5", "a3"]

    def outModels(self):
        print("These are the available models for Audi")
        for model in self.models:
            print("\t %s " % model)

def show():
    print("I'm in show")

def show2():
    print("I'm in show2")