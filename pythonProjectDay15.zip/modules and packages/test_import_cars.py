#import bmw, audi classes form cars
from cars import bmw

bmw = bmw.Bmw()
bmw.outModels()

from cars.audi import Audi

audi = Audi()
audi.outModels()

from cars.audi import *

